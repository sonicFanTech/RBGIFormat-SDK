# RBGI Format SDK API

Main header:

```txt
include/RbgiFormat.h
```

Namespace:

```cpp
namespace RBGI
```

## Types

### `ImageMode`

```cpp
enum class ImageMode : quint32
{
    FlatImage = 0,
    RenderBackground = 1,
    SkyBoxSingleTexture = 2,
    SkyBoxCubeTexture = 3
};
```

### `Document`

```cpp
struct Document
{
    bool valid = false;
    bool legacyRenamedPng = false;
    quint16 version = 1;
    quint32 width = 0;
    quint32 height = 0;
    ImageMode mode = ImageMode::RenderBackground;
    quint32 flags = 0;
    QJsonObject metadata;
    QByteArray pngBytes;
    QImage image;
    QString error;
};
```

## Functions

```cpp
QString modeToString(ImageMode mode);
ImageMode modeFromIndex(int index);
bool looksLikeRealRbgi(const QByteArray& bytes);
Document loadFile(const QString& filePath);
bool saveFile(const QString& filePath, const QImage& image, ImageMode mode, const QJsonObject& metadata, QString* errorOut = nullptr);
bool saveLegacyPngAsRbgi(const QString& filePath, const QImage& image, QString* errorOut = nullptr);
```
