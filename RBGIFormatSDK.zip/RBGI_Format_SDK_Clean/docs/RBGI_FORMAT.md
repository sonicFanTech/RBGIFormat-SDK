# RBGI v1 Format Specification

This document describes the current `.RBGI` v1 file layout implemented by `RbgiFormat.cpp`.

## Endianness

The binary header is written using `QDataStream` with little-endian byte order.

```cpp
stream.setByteOrder(QDataStream::LittleEndian);
```

## File layout

```txt
[Header][Metadata JSON][Embedded PNG]
```

## Header

| Offset | Type | Name | Description |
|---:|---|---|---|
| 0 | char[4] | magic | ASCII `RBGI` |
| 4 | quint16 | version | Current format version: `1` |
| 6 | quint32 | headerSize | Current header size: `38` |
| 10 | quint32 | width | Header image width |
| 14 | quint32 | height | Header image height |
| 18 | quint32 | mode | `RBGI::ImageMode` value |
| 22 | quint32 | flags | Reserved, currently `0` |
| 26 | quint64 | pngSize | Number of PNG bytes after metadata |
| 34 | quint32 | metadataSize | Number of JSON metadata bytes |

After the 38-byte header, the file stores `metadataSize` bytes of compact JSON metadata, followed by `pngSize` bytes of PNG image data.

## Image modes

```cpp
enum class ImageMode : quint32
{
    FlatImage = 0,
    RenderBackground = 1,
    SkyBoxSingleTexture = 2,
    SkyBoxCubeTexture = 3
};
```

## Legacy files

If a file does not begin with `RBGI`, the loader tries to decode it as PNG data. If that succeeds, the file is treated as a legacy renamed-PNG `.RBGI` file.

## Limits

The loader rejects metadata larger than 8 MiB and embedded PNG data larger than 512 MiB.
