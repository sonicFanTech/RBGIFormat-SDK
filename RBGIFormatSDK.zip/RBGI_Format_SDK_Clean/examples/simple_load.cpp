#include <QCoreApplication>
#include <QDebug>
#include "RbgiFormat.h"

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);

    if (argc < 2)
    {
        qWarning() << "Usage: simple_load <file.RBGI>";
        return 1;
    }

    RBGI::Document doc = RBGI::loadFile(QString::fromLocal8Bit(argv[1]));
    if (!doc.valid)
    {
        qWarning() << "Failed to load RBGI:" << doc.error;
        return 1;
    }

    qDebug() << "Loaded RBGI";
    qDebug() << "Size:" << doc.width << "x" << doc.height;
    qDebug() << "Mode:" << RBGI::modeToString(doc.mode);
    qDebug() << "Legacy renamed PNG:" << doc.legacyRenamedPng;
    qDebug() << "Metadata:" << doc.metadata;

    return 0;
}
