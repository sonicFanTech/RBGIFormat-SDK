#include <QCoreApplication>
#include <QDebug>
#include <QImage>
#include <QJsonObject>
#include "RbgiFormat.h"

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);

    if (argc < 3)
    {
        qWarning() << "Usage: simple_save <input.png> <output.RBGI>";
        return 1;
    }

    QImage image(QString::fromLocal8Bit(argv[1]));
    if (image.isNull())
    {
        qWarning() << "Could not load input image.";
        return 1;
    }

    QJsonObject metadata;
    metadata["format"] = "RBGI";
    metadata["name"] = "Render Background Image";
    metadata["type"] = "RenderBackgroundImage";
    metadata["createdWith"] = "RBGI Format SDK example";

    QString error;
    if (!RBGI::saveFile(QString::fromLocal8Bit(argv[2]), image, RBGI::ImageMode::RenderBackground, metadata, &error))
    {
        qWarning() << "Could not save RBGI:" << error;
        return 1;
    }

    qDebug() << "Saved RBGI file.";
    return 0;
}
