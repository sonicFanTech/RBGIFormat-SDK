#include "RbgiFormat.h"

#include <QBuffer>
#include <QDataStream>
#include <QFile>
#include <QJsonDocument>

namespace
{
    constexpr char kMagic[4] = { 'R', 'B', 'G', 'I' };
    constexpr quint16 kVersion = 1;
    constexpr quint32 kHeaderSize = 38;

    bool readExact(QDataStream& stream, char* data, int size)
    {
        return stream.readRawData(data, size) == size;
    }
}

namespace RBGI
{
    QString modeToString(ImageMode mode)
    {
        switch (mode)
        {
        case ImageMode::FlatImage: return "Flat Image";
        case ImageMode::RenderBackground: return "Render Background";
        case ImageMode::SkyBoxSingleTexture: return "SkyBox Single Texture";
        case ImageMode::SkyBoxCubeTexture: return "SkyBox Cube Texture";
        default: return "Unknown";
        }
    }

    ImageMode modeFromIndex(int index)
    {
        switch (index)
        {
        case 0: return ImageMode::FlatImage;
        case 1: return ImageMode::RenderBackground;
        case 2: return ImageMode::SkyBoxSingleTexture;
        case 3: return ImageMode::SkyBoxCubeTexture;
        default: return ImageMode::RenderBackground;
        }
    }

    bool looksLikeRealRbgi(const QByteArray& bytes)
    {
        return bytes.size() >= 4 && bytes[0] == 'R' && bytes[1] == 'B' && bytes[2] == 'G' && bytes[3] == 'I';
    }

    Document loadFile(const QString& filePath)
    {
        Document doc;

        QFile file(filePath);
        if (!file.open(QIODevice::ReadOnly))
        {
            doc.error = "Could not open file for reading.";
            return doc;
        }

        const QByteArray bytes = file.readAll();
        if (bytes.isEmpty())
        {
            doc.error = "File is empty.";
            return doc;
        }

        if (!looksLikeRealRbgi(bytes))
        {
            QImage legacy;
            if (!legacy.loadFromData(bytes, "PNG"))
            {
                doc.error = "This .RBGI file is not a real RBGI v1 file and is not valid legacy PNG data.";
                return doc;
            }

            doc.valid = true;
            doc.legacyRenamedPng = true;
            doc.width = legacy.width();
            doc.height = legacy.height();
            doc.image = legacy.convertToFormat(QImage::Format_RGBA8888);
            doc.mode = ImageMode::RenderBackground;
            doc.pngBytes = bytes;
            doc.metadata = QJsonObject{
                { "format", "Legacy renamed PNG .RBGI" },
                { "name", "Legacy RBGI Image" },
                { "type", "RenderBackgroundImage" }
            };
            return doc;
        }

        QDataStream stream(bytes);
        stream.setByteOrder(QDataStream::LittleEndian);

        char magic[4] = {};
        quint16 version = 0;
        quint32 headerSize = 0;
        quint32 width = 0;
        quint32 height = 0;
        quint32 modeRaw = 0;
        quint32 flags = 0;
        quint64 pngSize = 0;
        quint32 metadataSize = 0;

        if (!readExact(stream, magic, 4) || magic[0] != kMagic[0] || magic[1] != kMagic[1] || magic[2] != kMagic[2] || magic[3] != kMagic[3])
        {
            doc.error = "Invalid RBGI magic header.";
            return doc;
        }

        stream >> version >> headerSize >> width >> height >> modeRaw >> flags >> pngSize >> metadataSize;
        if (stream.status() != QDataStream::Ok)
        {
            doc.error = "Could not read the RBGI header.";
            return doc;
        }

        if (version != kVersion)
        {
            doc.error = QString("Unsupported RBGI version: %1").arg(version);
            return doc;
        }

        if (headerSize < kHeaderSize)
        {
            doc.error = "Invalid RBGI header size.";
            return doc;
        }

        if (headerSize > kHeaderSize)
        {
            const quint32 extraBytes = headerSize - kHeaderSize;
            if (stream.skipRawData(static_cast<int>(extraBytes)) != static_cast<int>(extraBytes))
            {
                doc.error = "Could not skip unknown future header data.";
                return doc;
            }
        }

        if (metadataSize > 1024 * 1024 * 8)
        {
            doc.error = "RBGI metadata is too large.";
            return doc;
        }

        if (pngSize > 1024ULL * 1024ULL * 512ULL)
        {
            doc.error = "Embedded PNG data is too large.";
            return doc;
        }

        QByteArray metadataBytes;
        metadataBytes.resize(static_cast<int>(metadataSize));
        if (metadataSize > 0 && !readExact(stream, metadataBytes.data(), metadataBytes.size()))
        {
            doc.error = "Could not read RBGI metadata.";
            return doc;
        }

        QByteArray pngBytes;
        pngBytes.resize(static_cast<int>(pngSize));
        if (pngSize > 0 && !readExact(stream, pngBytes.data(), pngBytes.size()))
        {
            doc.error = "Could not read embedded PNG image data.";
            return doc;
        }

        QJsonObject metadata;
        if (!metadataBytes.isEmpty())
        {
            QJsonParseError parseError;
            const QJsonDocument metadataDoc = QJsonDocument::fromJson(metadataBytes, &parseError);
            if (parseError.error != QJsonParseError::NoError || !metadataDoc.isObject())
            {
                doc.error = "RBGI metadata JSON is invalid.";
                return doc;
            }
            metadata = metadataDoc.object();
        }

        QImage image;
        if (!image.loadFromData(pngBytes, "PNG"))
        {
            doc.error = "Embedded PNG image data is invalid.";
            return doc;
        }

        doc.valid = true;
        doc.legacyRenamedPng = false;
        doc.version = version;
        doc.width = width;
        doc.height = height;
        doc.mode = static_cast<ImageMode>(modeRaw);
        doc.flags = flags;
        doc.metadata = metadata;
        doc.pngBytes = pngBytes;
        doc.image = image.convertToFormat(QImage::Format_RGBA8888);
        return doc;
    }

    bool saveFile(const QString& filePath, const QImage& image, ImageMode mode, const QJsonObject& metadata, QString* errorOut)
    {
        if (image.isNull())
        {
            if (errorOut) *errorOut = "No image loaded.";
            return false;
        }

        QByteArray pngBytes;
        QBuffer pngBuffer(&pngBytes);
        pngBuffer.open(QIODevice::WriteOnly);
        if (!image.save(&pngBuffer, "PNG"))
        {
            if (errorOut) *errorOut = "Could not encode image as PNG.";
            return false;
        }

        const QByteArray metadataBytes = QJsonDocument(metadata).toJson(QJsonDocument::Compact);

        QFile file(filePath);
        if (!file.open(QIODevice::WriteOnly))
        {
            if (errorOut) *errorOut = "Could not open file for writing.";
            return false;
        }

        QDataStream stream(&file);
        stream.setByteOrder(QDataStream::LittleEndian);

        stream.writeRawData(kMagic, 4);
        stream << kVersion;
        stream << kHeaderSize;
        stream << static_cast<quint32>(image.width());
        stream << static_cast<quint32>(image.height());
        stream << static_cast<quint32>(mode);
        stream << static_cast<quint32>(0); // Flags reserved for future versions.
        stream << static_cast<quint64>(pngBytes.size());
        stream << static_cast<quint32>(metadataBytes.size());
        stream.writeRawData(metadataBytes.constData(), metadataBytes.size());
        stream.writeRawData(pngBytes.constData(), pngBytes.size());

        if (stream.status() != QDataStream::Ok)
        {
            if (errorOut) *errorOut = "A write error happened while saving the RBGI file.";
            return false;
        }

        return true;
    }

    bool saveLegacyPngAsRbgi(const QString& filePath, const QImage& image, QString* errorOut)
    {
        if (image.isNull())
        {
            if (errorOut) *errorOut = "No image loaded.";
            return false;
        }
        if (!image.save(filePath, "PNG"))
        {
            if (errorOut) *errorOut = "Could not save legacy renamed-PNG .RBGI file.";
            return false;
        }
        return true;
    }
}
