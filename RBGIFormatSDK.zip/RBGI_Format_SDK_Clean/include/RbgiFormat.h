#pragma once

#include <QByteArray>
#include <QImage>
#include <QJsonObject>
#include <QString>

#if defined(RBGIFORMAT_LIBRARY)
#define RBGI_API __declspec(dllexport)
#else
#define RBGI_API __declspec(dllimport)
#endif

namespace RBGI
{
    enum class ImageMode : quint32
    {
        FlatImage = 0,
        RenderBackground = 1,
        SkyBoxSingleTexture = 2,
        SkyBoxCubeTexture = 3
    };

    struct Document
    {
        bool valid = false;
        bool legacyRenamedPng = false;
        quint16 version = 1;
        quint32 width = 0;
        quint32 height = 0;
        ImageMode mode = ImageMode::RenderBackground;
        quint32 flags = 0;
        QJsonObject metadata;
        QByteArray pngBytes;
        QImage image;
        QString error;
    };

    RBGI_API QString modeToString(ImageMode mode);
    RBGI_API ImageMode modeFromIndex(int index);
    RBGI_API bool looksLikeRealRbgi(const QByteArray& bytes);

    RBGI_API Document loadFile(const QString& filePath);
    RBGI_API bool saveFile(const QString& filePath, const QImage& image, ImageMode mode, const QJsonObject& metadata, QString* errorOut = nullptr);
    RBGI_API bool saveLegacyPngAsRbgi(const QString& filePath, const QImage& image, QString* errorOut = nullptr);
}
